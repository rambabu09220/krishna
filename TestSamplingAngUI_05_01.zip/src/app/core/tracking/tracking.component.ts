import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, ChangeDetectorRef, AfterViewChecked, HostListener } from '@angular/core';
import { MatTableDataSource, MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { TrackingService } from './tracking.service';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { PdfComponent } from 'src/app/shared/pdf/pdf.component';


export interface PeriodicElement {
  id: number;
  task: string;
  assignedResource: string;
  startDate: string;
  endDate: string;
  actualCompletionDt: string;
  status: string;
  note: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {id: 1, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 2, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 3, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 4, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 5, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 6, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 7, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 8, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 9, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 10, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 11, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 12, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 13, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 14, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 15, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 16, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 17, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 18, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 19, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 20, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 21, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 22, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 23, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 24, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 25, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''}
];

@Component({
  selector: 'app-tracking',
  templateUrl: './tracking.component.html',
  styleUrls: ['./tracking.component.scss']
})
export class TrackingComponent implements OnInit, AfterViewInit, AfterViewChecked {
  @ViewChild('taskTable') taskTableRef: ElementRef;
  @ViewChild('todayTaskRef') todayTaskRef: ElementRef;
  filterValue = '1';
  taskId: string;
  displayedColumns: string[] = ['id', 'task', 'assignedResource', 'startDate', 'endDate', 'actualCompletionDt', 'status', 'note'];
  dropDOwnColumns: string[] = ['rotation', 'todayTask', 'due', 'todayStatus'];
  data: any[];
  pages: any[];
  currentPage = 1;
  pageSize = 12;
  dataSource: any;
  dropdownDataSource: any;
  ddWidth: any;
  selectedRow: PeriodicElement;
  tableRowHeight: number;
  constructor( private router: Router, private trackingService: TrackingService,
     public dialog: MatDialog, private cdRef: ChangeDetectorRef) {
  }
  @HostListener('window:resize')
  changeHeight(): void {
    const tableHeight = this.taskTableRef.nativeElement.offsetHeight;
    this.tableRowHeight = (tableHeight - 35) / 12;
    this.ddWidth = this.todayTaskRef.nativeElement.offsetWidth - 27;
    this.cdRef.detectChanges();
  }
  ngOnInit() {
    this.data = ELEMENT_DATA;
    this.selectedRow = this.data[0];
    const totalPages = Math.ceil(this.data.length / this.pageSize);
    this.geneartePages(totalPages);
    this.paginator(this.currentPage);
    this.dropdownDataSource = ELEMENT_DATA.slice(0, 10);
    this.trackingService.getTrackingInfo(217, true).subscribe((data) => {
      console.log(data);
    }, (error) => {
      console.log(error);
    });
    this.cdRef.detectChanges();
  }

  ngAfterViewInit() {
    console.log(this.taskTableRef.nativeElement);
    if (this.taskTableRef) {
      const tableHeight = this.taskTableRef.nativeElement.offsetHeight;
      this.tableRowHeight = (tableHeight - 35) / 12;
      this.cdRef.detectChanges();
    }

  }

  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }

  geneartePages(value: any) {
    this.pages = [];
    for ( let i = 1 ; i <= value; i++) {
      this.pages.push(i);
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = this.filterValue.trim().toLowerCase();
  }

  refresh(): void {

  }

  printPdf(data): void {
    let doc = new jsPDF('p', 'pt');
    const columns = [
      {title: 'ID', dataKey: 'id'},
      {title: 'Task', dataKey: 'task'},
      {title: 'AssignedResource', dataKey: 'assignedResource'},
      {title: 'StartDate', dataKey: 'startDate'},
      {title: 'EdDate', dataKey: 'endDate'},
      {title: 'ActualCompletionDt', dataKey: 'actualCompletionDt'},
      {title: 'Atatus', dataKey: 'status'},
      {title: 'Note', dataKey: 'note'},
    ];
    doc.autoTable(columns, data);
    doc.setFontSize(10);
    doc.text(40, 30, '112(private)');
    doc.text(480, 30, new Date().toDateString());
    doc.setCreationDate(new Date());
    doc.save('table.pdf');
  }

  openPdf() {
    const dialogRef = this.dialog.open(PdfComponent, { width: '400px'});
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      if (result === 'all') {
        this.printPdf(ELEMENT_DATA);
      } else if (result === 'current') {
        let data = ELEMENT_DATA.slice((this.currentPage * this.pageSize) - this.pageSize, (this.currentPage * this.pageSize));
        this.printPdf(data);
      }
    });
  }

  searchTaskId(): void {
    console.log(this.taskId);
  }

  openTaskView(): void {
    this.router.navigate(['taskView']);
  }

  toggle(e) {
    e.target.classList.toggle('active');
    const content = e.target.nextElementSibling;
    if (content.style.maxHeight) {
      content.style.maxHeight = null;
      content.style.border = 'none';
    } else {
      content.style.maxHeight = '200px';
      content.style.maxWidth = e.srcElement.offsetWidth + 'px';
      console.log(e.srcElement.offsetWidth, 'width');
      this.ddWidth = e.srcElement.offsetWidth - 27 + 'px';
      content.style.border = '5px solid rgba(0,0,0,.15)';
    }
  }

  paginator(value) {
    this.currentPage = value;
    const values = ELEMENT_DATA.slice((value * this.pageSize) - this.pageSize, (value * this.pageSize));
    this.dataSource = new MatTableDataSource(values);
  }

  highlightRow(row: any): void {
    console.log(row);
    this.selectedRow = row;
  }
}
