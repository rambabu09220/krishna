import { Injectable } from '@angular/core';
import { DataService, ServiceParams } from '../../common/services/data-service.service';
import { Observable } from 'rxjs';
import { APIURL } from '../../common/constants/app-url.constant';


@Injectable({
  providedIn: 'root'
})
export class TrackingService {

  constructor(private dataService: DataService) { }

  getTrackingInfo(rotationGrpNum: number, isCurrent: boolean = false): Observable<any> {
    const url = APIURL.API_URL + APIURL.API_METHOD_GET_TRACKING + rotationGrpNum + '/' + isCurrent;
    return this.dataService.callGetAPI(url);
  }
}
