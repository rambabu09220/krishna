import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';

export interface TaskResourceElement {
  name: string;
  role: string;
  phone: string;
}

export interface PredecessorElement {
  id: number;
  taskname: string;
  status: string;
}

const TABLE_DATA_TASK_RESOURCE: TaskResourceElement[] = [
  {name: 'Test1', role: 'Manager', phone: '123-456-7890'},
  {name: 'Test2', role: 'Manager', phone: '123-456-7890'},
  {name: 'Test3', role: 'Manager', phone: '123-456-7890'},
  {name: '', role: '', phone: ''}
];

const TABLE_DATA_PREDECESSOR: PredecessorElement[] = [
  {id: 1, taskname: 'Manager', status: 'Status1'},
  {id: 2, taskname: 'Manager', status: 'Status2'},
  {id: 3, taskname: 'Manager', status: 'Status3'},
  {id: 4, taskname: '', status: ''}
];


@Component({
  selector: 'app-task-details',
  templateUrl: './task-details.component.html',
  styleUrls: ['./task-details.component.scss']
})
export class TaskDetailsComponent implements OnInit {
  taskResourceColumns: string[] = ['name', 'role', 'phone'];
  taskResourceList = new MatTableDataSource(TABLE_DATA_TASK_RESOURCE);
  predecessorColumns: string[] = ['id', 'taskname', 'status'];
  predecessorList = new MatTableDataSource(TABLE_DATA_PREDECESSOR);

  constructor() { }

  ngOnInit() {
  }

}
