import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';

export interface AreaReportElement {
  state: string;
  county: string;
  countyName: string;
  sampleArea: string;
  ombArea: string;
}

const ELEMENT_DATA: AreaReportElement[] = [
  {state: '1', county: 'Hydrogen', countyName: 'Ram', sampleArea: 'H', ombArea: ''},
  {state: '2', county: 'Hydrogen', countyName: 'Ram', sampleArea: 'H', ombArea: ''},
  {state: '3', county: 'Hydrogen', countyName: 'Ram', sampleArea: 'H', ombArea: ''},
  {state: '4', county: 'Hydrogen', countyName: 'Ram', sampleArea: 'H', ombArea: ''},
  {state: '5', county: 'Hydrogen', countyName: 'Ram', sampleArea: 'H', ombArea: ''},
  {state: '6', county: 'Hydrogen', countyName: 'Ram', sampleArea: 'H', ombArea: ''},
  {state: '7', county: 'Hydrogen', countyName: 'Ram', sampleArea: 'H', ombArea: ''},
  {state: '8', county: 'Hydrogen', countyName: 'Ram', sampleArea: 'H', ombArea: ''},
  // {state: '9', county: 'Hydrogen', countyName: 'Ram', sampleArea: 'H', ombArea: ''}
];

@Component({
  selector: 'app-area-report',
  templateUrl: './area-report.component.html',
  styleUrls: ['./area-report.component.scss']
})
export class AreaReportComponent implements OnInit {
  areaReportColumns: string[] = ['state', 'county', 'countyName', 'sampleArea', 'ombArea'];
  areaReportList = new MatTableDataSource(ELEMENT_DATA);

  constructor() { }

  ngOnInit() {
  }

}

