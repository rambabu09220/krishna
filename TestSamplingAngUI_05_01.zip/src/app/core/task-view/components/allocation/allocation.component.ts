import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';

export interface CertaintyReportElement {
  passFail: string;
  area: string;
  aggregateIndStr: string;
  areaName: string;
  certaintyAllo: string;
  nonCerAl: string;
  frame: string;
  updatedA: string;
}
const ELEMENT_DATA: CertaintyReportElement[] = [
  {passFail: '1', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '2', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '3', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '4', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '5', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '6', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '7', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '8', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '9', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '11', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '12', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '13', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '14', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '15', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '16', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '17', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '18', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '19', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '11', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '12', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '13', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '14', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '15', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '16', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '17', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '18', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''},
  {passFail: '19', area: 'Hydrogen', aggregateIndStr: 'Ram', areaName: 'H', certaintyAllo: '', nonCerAl: '', frame: '', updatedA: ''}
];


@Component({
  selector: 'app-allocation',
  templateUrl: './allocation.component.html',
  styleUrls: ['./allocation.component.scss']
})

export class AllocationComponent implements OnInit {
  allocationReportColumns: string[] = ['passFail', 'area', 'aggregateIndStr', 'areaName', 'certaintyAllo', 'nonCerAl', 'frame', 'updatedA'];
  allocationReportList = new MatTableDataSource(ELEMENT_DATA);
  constructor() { }

  ngOnInit() {
  }

}

