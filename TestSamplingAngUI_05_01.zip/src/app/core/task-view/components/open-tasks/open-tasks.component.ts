import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';

export interface AreaReportElement {
  id: string;
  task: string;
  assignedResource: string;
  endDate: string;
}
const ELEMENT_DATA: AreaReportElement[] = [
  {id: '1', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '2', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '3', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '4', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '5', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '6', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '7', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '8', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '9', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '2', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '3', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '4', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '5', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '6', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '7', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '8', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'},
  {id: '9', task: 'Hydrogen', assignedResource: 'Ram', endDate: 'H'}
];


@Component({
  selector: 'app-open-tasks',
  templateUrl: './open-tasks.component.html',
  styleUrls: ['./open-tasks.component.scss']
})
export class OpenTasksComponent implements OnInit {
  openTaskColumns: string[] = ['id', 'task', 'assignedResource', 'endDate'];
  openTaskList = new MatTableDataSource(ELEMENT_DATA);


  constructor() { }

  ngOnInit() {
  }

}
