import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RunJObComponent } from './run-job.component';

describe('RunJObComponent', () => {
  let component: RunJObComponent;
  let fixture: ComponentFixture<RunJObComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RunJObComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RunJObComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
