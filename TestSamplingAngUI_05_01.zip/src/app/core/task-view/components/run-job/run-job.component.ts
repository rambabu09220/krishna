import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';

export interface RunJobElement {
  module: string;
  status: string;
}
const ELEMENT_DATA: RunJobElement[] = [
  {module: 'Rotation Schedule Report', status: 'Completed Successfully'},
  {module: '', status: ''},
  {module: '', status: ''},
  {module: '', status: ''},
  {module: '', status: ''}
];

@Component({
  selector: 'app-run-job',
  templateUrl: './run-job.component.html',
  styleUrls: ['./run-job.component.scss']
})
export class RunJObComponent implements OnInit {
  runJobColumns: string[] = ['module', 'status'];
  runJobList = new MatTableDataSource(ELEMENT_DATA);

  constructor() { }

  ngOnInit() {
  }

}
