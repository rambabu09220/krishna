import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';

export interface CertaintyReportElement {
  delete: string;
  origLDB: string;
  LegalName: string;
  state: string;
  county: string;
  ein: string;
  uiNum: string;
  ldbMatch: string;
}

const ELEMENT_DATA: CertaintyReportElement[] = [
  {delete: '1', origLDB: 'Hydrogen', LegalName: 'Ram', state: 'H', county: '', ein: '', uiNum: '', ldbMatch: ''},
  {delete: '2', origLDB: 'Hydrogen', LegalName: 'Ram', state: 'H', county: '', ein: '', uiNum: '', ldbMatch: ''},
  {delete: '3', origLDB: 'Hydrogen', LegalName: 'Ram', state: 'H', county: '', ein: '', uiNum: '', ldbMatch: ''},
  {delete: '4', origLDB: 'Hydrogen', LegalName: 'Ram', state: 'H', county: '', ein: '', uiNum: '', ldbMatch: ''},
  {delete: '5', origLDB: 'Hydrogen', LegalName: 'Ram', state: 'H', county: '', ein: '', uiNum: '', ldbMatch: ''},
  {delete: '6', origLDB: 'Hydrogen', LegalName: 'Ram', state: 'H', county: '', ein: '', uiNum: '', ldbMatch: ''},
  {delete: '7', origLDB: 'Hydrogen', LegalName: 'Ram', state: 'H', county: '', ein: '', uiNum: '', ldbMatch: ''},
  {delete: '8', origLDB: 'Hydrogen', LegalName: 'Ram', state: 'H', county: '', ein: '', uiNum: '', ldbMatch: ''},
  {delete: '9', origLDB: 'Hydrogen', LegalName: 'Ram', state: 'H', county: '', ein: '', uiNum: '', ldbMatch: ''}
];
@Component({
  selector: 'app-certainty',
  templateUrl: './certainty.component.html',
  styleUrls: ['./certainty.component.scss']
})

export class CertaintyComponent implements OnInit {
  certaintyreportColumns: string[] = ['delete', 'origLDB', 'LegalName', 'state', 'county', 'ein', 'uiNum', 'ldbMatch'];
  certainityList = new MatTableDataSource(ELEMENT_DATA);
  constructor() { }

  ngOnInit() {
  }

}

