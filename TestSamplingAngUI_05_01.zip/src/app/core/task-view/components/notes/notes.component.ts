import { Component, OnInit } from '@angular/core';
import { faPlusCircle, faUndoAlt, faSave, faGlobeAmericas, faTimes, faWrench, faEnvelope } from '@fortawesome/free-solid-svg-icons';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.scss']
})
export class NotesComponent implements OnInit {
  faPlusCircle = faPlusCircle;
  faUndoAlt = faUndoAlt;
  faSave = faSave;
  faGlobeAmericas = faGlobeAmericas;
  faTimes = faTimes;
  faWrench = faWrench;
  faEnvelope = faEnvelope;

  currentDate: Date = new Date();
  newNote: boolean;
  draftNotes = [];
  publishedNotes = [];
  publishNote: any;
  constructor(private fb: FormBuilder) { }

  notesForm = this.fb.group({
    subject: ['', Validators.required],
    importance: [''],
    status: [''],
    note: [''],
  });

  ngOnInit() {
  }

  addNote(): void {
    this.newNote = true;
  }

  onSubmit() {
    if (this.notesForm.valid) {
      this.draftNotes.push(this.notesForm.value);
      this.notesForm.reset();
    }
  }

  publish() {
    this.notesForm.reset();
    if (this.publishNote) {
      const index = this.draftNotes.findIndex(item => item.subject === this.publishNote.subject);
      this.publishedNotes.push(this.publishNote);
      this.draftNotes.splice(index, 1);
    }
  }

  setForm(note) {
    this.publishNote = note;
    this.notesForm.patchValue({
      subject: note.subject,
      importance: note.importance,
      status: note.status,
      note : note.note
    });
  }
  deleteNote() {
    if (this.publishNote) {
      const index = this.draftNotes.findIndex(item => item.subject === this.publishNote.subject);
      this.draftNotes.splice(index, 1);
      this.notesForm.reset();
    }
  }

}
