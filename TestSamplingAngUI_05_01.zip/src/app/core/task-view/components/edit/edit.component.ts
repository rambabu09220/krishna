import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit {
  resourceList: Array<Object>;
  constructor() {
  }

  ngOnInit() {
    this.resourceList = [
      {
        name: 'Rambabu Mandati',
        id: 1
      },
      {
        name: 'Drayton-Hillary',
        id: 2
      },
      {
        name: 'Renee Marshall',
        id: 3
      }
    ];
  }

}
