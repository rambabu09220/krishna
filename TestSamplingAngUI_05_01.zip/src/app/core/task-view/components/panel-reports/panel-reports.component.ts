import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { MatTableDataSource, MatDialogRef } from '@angular/material';

export interface EsthablishmentElement {
  id: number;
  areaName: string;
  panel1: string;
  panel2: string;
  panel3: string;
  panel4: string;
  certainityEstabs: string;
  nonCertainityEstabs: string;
}

const ELEMENT_DATA: EsthablishmentElement[] = [
  { id: 1, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  { id: 2, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  { id: 3, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 4, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 5, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 6, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 7, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 8, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 9, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' }
];

export interface WeightedEmploymentElement {
  id: number;
  areaName: string;
  panel1: string;
  panel2: string;
  panel3: string;
  panel4: string;
  certainityEstabs: string;
  nonCertainityEstabs: string;
}

const WEIGHTED_EMPLOYMENT_DATA: WeightedEmploymentElement[] = [
  { id: 1, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  { id: 2, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  { id: 3, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 4, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 5, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 6, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 7, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 8, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' },
  // { id: 9, panel1: 'Hydrogen', panel2: 'Ram', panel3: 'H', panel4: '', certainityEstabs: '', nonCertainityEstabs: '', areaName: '' }
];

export interface AdjustedEmploymentElement {
  id: number;
  areaName: string;
  goodsProducing: string;
  fir: string;
  education: string;
  healthCare: string;
  serviceProviding: string;
  aircraftMF: string;
  allIndustries: string;
}

const ADJUSTED_EMPLOYMENT_DATA: AdjustedEmploymentElement[] = [
  {
    id: 1, goodsProducing: 'Hydrogen', fir: 'Ram', education: 'H', healthCare: '',
    serviceProviding: '', aircraftMF: '', areaName: '', allIndustries: ''
  },
  {
    id: 2, goodsProducing: 'Hydrogen', fir: 'Ram', education: 'H', healthCare: '',
    serviceProviding: '', aircraftMF: '', areaName: '', allIndustries: ''
  },
  {
    id: 3, goodsProducing: 'Hydrogen', fir: 'Ram', education: 'H', healthCare: '',
    serviceProviding: '', aircraftMF: '', areaName: '', allIndustries: ''
  },
  // {
  //   id: 4, goodsProducing: 'Hydrogen', fir: 'Ram', education: 'H', healthCare: '',
  //   serviceProviding: '', aircraftMF: '', areaName: '', allIndustries: ''
  // },
  // {
  //   id: 5, goodsProducing: 'Hydrogen', fir: 'Ram', education: 'H', healthCare: '',
  //   serviceProviding: '', aircraftMF: '', areaName: '', allIndustries: ''
  // },
  // {
  //   id: 6, goodsProducing: 'Hydrogen', fir: 'Ram', education: 'H', healthCare: '',
  //   serviceProviding: '', aircraftMF: '', areaName: '', allIndustries: ''
  // },
  // {
  //   id: 7, goodsProducing: 'Hydrogen', fir: 'Ram', education: 'H', healthCare: '',
  //   serviceProviding: '', aircraftMF: '', areaName: '', allIndustries: ''
  // },
  // {
  //   id: 8, goodsProducing: 'Hydrogen', fir: 'Ram', education: 'H', healthCare: '',
  //   serviceProviding: '', aircraftMF: '', areaName: '', allIndustries: ''
  // },
  // {
  //   id: 9, goodsProducing: 'Hydrogen', fir: 'Ram', education: 'H', healthCare: '',
  //   serviceProviding: '', aircraftMF: '', areaName: '', allIndustries: ''
  // }
];

@Component({
  selector: 'app-panel-reports',
  templateUrl: './panel-reports.component.html',
  styleUrls: ['./panel-reports.component.scss']
})
export class PanelReportsComponent implements OnInit {
  modalWindowHeight = 300;
  groupNumber: number;
  esthablishmentColumns: string[] = ['areaName', 'panel1', 'panel2', 'panel3', 'panel4', 'certainityEstabs', 'nonCertainityEstabs'];
  esthablishmentList = new MatTableDataSource(ELEMENT_DATA);
  weightedEmploymentColumns: string[] = ['areaName', 'panel1', 'panel2', 'panel3', 'panel4', 'certainityEstabs', 'nonCertainityEstabs'];
  weigthedEmploymentList = new MatTableDataSource(WEIGHTED_EMPLOYMENT_DATA);
  adjustedEmploymentColumns: string[] = ['areaName', 'goodsProducing', 'fir',
    'education', 'healthCare', 'serviceProviding', 'aircraftMF', 'allIndustries'];
  adjustedEmploymentList = new MatTableDataSource(ADJUSTED_EMPLOYMENT_DATA);
  constructor(public dialogRef: MatDialogRef<PanelReportsComponent>) { }

  ngOnInit() {
    this.modalWindowHeight = window.innerHeight - 100;
    this.groupNumber = 1234;
  }

  close(): void {
    this.dialogRef.close();
  }

}
