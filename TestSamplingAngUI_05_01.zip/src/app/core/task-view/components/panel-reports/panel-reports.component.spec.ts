import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PanelReportsComponent } from './panel-reports.component';

describe('PanelReportsComponent', () => {
  let component: PanelReportsComponent;
  let fixture: ComponentFixture<PanelReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PanelReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PanelReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
