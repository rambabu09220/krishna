import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatDialog } from '@angular/material';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PanelReportsComponent } from '../panel-reports/panel-reports.component';

export interface PanelChangeElement {
  id: number;
  task: string;
  assignedResource: string;
  startDate: string;
  endDate: string;
  actualCompletionDt: string;
  status: string;
  note: string;
}

export interface ColumnElement {
  prop: string;
  label: string;
  column: string;
}

const ELEMENT_DATA: PanelChangeElement[] = [
  {id: 1, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 2, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 3, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 4, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 5, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 6, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 7, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 8, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 9, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 1, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 2, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 3, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 4, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 5, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 6, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 7, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 8, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 9, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 7, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 8, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 9, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 1, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 2, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 3, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 4, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 5, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 6, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 7, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 8, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 9, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 1, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 2, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 3, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 4, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 5, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 6, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 7, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 8, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 9, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 7, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 8, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''},
  {id: 9, task: 'Hydrogen', assignedResource: 'Ram', startDate: 'H', endDate: '', actualCompletionDt: '', status: '', note: ''}
];

const COLUMN_DATA: ColumnElement[] = [
  {
    prop: 'ln',
    label: 'Legal Name',
    column: 'Legal Name'
  },
  {
    prop: 'ein',
    label: 'EIN',
    column: 'EIN'
  },
  {
    prop: 'uiNum',
    label: 'UI Number',
    column: 'UI Number'
  }
];

@Component({
  selector: 'app-panel',
  templateUrl: './panel.component.html',
  styleUrls: ['./panel.component.scss']
})
export class PanelComponent implements OnInit {
  panelChangeColumns: string[] = ['id', 'task', 'assignedResource', 'startDate', 'endDate', 'actualCompletionDt', 'status', 'note'];
  panelChangeList = new MatTableDataSource(ELEMENT_DATA);
  displayApprovalPanel: Boolean = false;
  menuList: ColumnElement[] = COLUMN_DATA;
  constructor(private modalService: NgbModal,  public dialog: MatDialog) { }

  ngOnInit() {
  }

  openReports(): void {
    this.dialog.open(PanelReportsComponent, { width: '1344px', maxWidth: '150vw'});
  }

  updateTableColumn(columnProp: string): void {
    console.log(columnProp);
  }

}
