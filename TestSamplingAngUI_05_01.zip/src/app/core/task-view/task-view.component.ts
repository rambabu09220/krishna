import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-task-view',
  templateUrl: './task-view.component.html',
  styleUrls: ['./task-view.component.scss']
})
export class TaskViewComponent implements OnInit {

  navLinks = [
    // {
    //   label: 'Task Details',
    //   link: 'taskDetails',
    //   index: 0
    // },
    // {
    //   label: 'Notes',
    //   link: 'notes',
    //   index: 1
    // },
    {
      label: 'Allocation Report',
      link: 'allocation',
      index: 2
    },
    // {
    //   label: 'Edit',
    //   link: 'edit',
    //   index: 3
    // },

    {
      label: 'Panel',
      link: 'panel',
      index: 4
    },

    {
      label: 'Send Email',
      link: 'sendMail',
      index: 5
    },

    {
      label: 'Certainty Report',
      link: 'certainity',
      index: 6
    },

    {
      label: 'Area Report',
      link: 'areaReport',
      index: 7
    },
    {
       label: ' Open Tasks',
       link: 'openTasks',
       index: 8
    },
    {
       label: 'Run Job',
       link: 'runJob',
       index: 9
    },
    // {
    //    label: 'Review',
    //    link: 'review',
    //    index: 10
    // }
  ];

  constructor(private router: Router) { }

  ngOnInit() {
  }

  handleClose(): void {
    this.router.navigate(['home']);
  }
}
