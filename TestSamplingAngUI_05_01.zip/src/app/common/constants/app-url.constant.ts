export class APIURL {
  // GLOBAL API URL.
  static API_URL = 'http://localhost:8115/samplingweb/';

  // API Methods.
  static API_METHOD_TODAYS_TASK = 'taskService/getTodaysTasks';
  static API_METHOD_GET_TRACKING = 'taskService/getTracking';
}
