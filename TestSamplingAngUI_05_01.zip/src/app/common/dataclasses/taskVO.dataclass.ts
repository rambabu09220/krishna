export class TaskVO {
  productId: number;
  phaseId: number;
}
