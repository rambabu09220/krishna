import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { APIURL } from '../constants/app-url.constant';

export class ServiceParams {
  service: string;
  method: string;
}


@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient) { }

  handleResponse(data: any): void {
    console.log(data);
  }

  handleError(error: any): void {
    console.log(error);
  }

  callGetAPI(url: string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Access-Control-Allow-Origin': '*'
      })
    };
    return this.http.get(url, httpOptions).pipe(
      tap(
        resp => this.handleResponse(resp),
        error => this.handleError(error)
      )
    );
  }

  callPostAPI(config: ServiceParams, data: any): Observable<any> {
    const url = APIURL + '/' + config.service + '/' + config.method;
    return this.http.post(url, data).pipe(
      tap(
        resp => this.handleResponse(resp),
        error => this.handleError(error)
      )
    );
  }
}
