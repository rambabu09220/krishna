import { Component, HostListener, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],

})
export class AppComponent {
  title = 'SamplingAng';
  myInnerHeight = window.innerHeight;

  getWindowHeight(): string {
    return window.innerHeight + 'px';
  }

  getWindowSize(event): void {
    this.myInnerHeight = window.innerHeight;
  }
}
