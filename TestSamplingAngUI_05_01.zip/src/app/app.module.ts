import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule} from '@fortawesome/angular-fontawesome';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { MatTableModule, MatTabsModule, MatMenuModule, MatRadioModule, MatDialogModule, MatButtonModule, MatListModule, MatInputModule } from '@angular/material';
import { AngularSplitModule } from 'angular-split';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TrackingComponent } from './core/tracking/tracking.component';
import { SharedModule } from './shared/shared.module';
import { TaskViewComponent } from './core/task-view/task-view.component';
import { TaskDetailsComponent } from './core/task-view/components/task-details/task-details.component';
import { NotesComponent } from './core/task-view/components/notes/notes.component';
import { RunJObComponent } from './core/task-view/components/run-job/run-job.component';
import { AreaReportComponent } from './core/task-view/components/area-report/area-report.component';
import { CertaintyComponent } from './core/task-view/components/certainty/certainty.component';
import { AllocationComponent } from './core/task-view/components/allocation/allocation.component';
import { ReviewComponent } from './core/task-view/components/review/review.component';
import { PanelComponent } from './core/task-view/components/panel/panel.component';
import { SendEmailComponent } from './core/task-view/components/send-email/send-email.component';
import { OpenTasksComponent } from './core/task-view/components/open-tasks/open-tasks.component';
import { EditComponent } from './core/task-view/components/edit/edit.component';
import { PanelReportsComponent } from './core/task-view/components/panel-reports/panel-reports.component';
import { PdfComponent } from './shared/pdf/pdf.component';

@NgModule({
  declarations: [
    AppComponent,
    TrackingComponent,
    TaskViewComponent,
    TaskDetailsComponent,
    NotesComponent,
    RunJObComponent,
    AreaReportComponent,
    CertaintyComponent,
    AllocationComponent,
    ReviewComponent,
    PanelComponent,
    SendEmailComponent,
    OpenTasksComponent,
    EditComponent,
    PanelReportsComponent,
    PdfComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    SharedModule,
    FontAwesomeModule,
    BsDropdownModule.forRoot(),
    AgGridModule.withComponents([]),
    MatTableModule,
    MatTabsModule,
    MatMenuModule,
    MatRadioModule,
    MatDialogModule,
    MatButtonModule,
    AngularSplitModule,
    ReactiveFormsModule,
    MatListModule,
    MatInputModule
  ],
  entryComponents: [
    PanelReportsComponent,
    PdfComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
