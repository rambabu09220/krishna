import { Component, OnInit, HostListener, ElementRef } from '@angular/core';
import { faCog } from '@fortawesome/free-solid-svg-icons';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SettingsComponent } from '../settings/settings.component';
import { ProfileComponent } from '../profile/profile.component';
import { HelpComponent } from '../help/help.component';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  faCog = faCog;
  content: any;
  display: any;
  constructor(private modalService: NgbModal, private eRef: ElementRef, public dialog: MatDialog) { }

  ngOnInit() {
  }

  openSettings(): void {
    this.dialog.open(SettingsComponent, { width: '700px'});
    this.display = 'none';
  }

  openProfile(): void {
    this.dialog.open(ProfileComponent, { width: '900px'});
    this.display = 'none';
  }

  openGoogle(): void {
    window.open('https://www.google.com', '_blank');
    this.display = 'none';
  }

  openHelp(): void {
    this.dialog.open(HelpComponent, { width: '900px'});
    this.display = 'none';
  }
  toggleDropDown(e) {
    const content = e.currentTarget.nextElementSibling;
    content.classList.toggle('active');
    this.content = content;
    if (content.style.display === '' || content.style.display === 'none') {
      content.style.display = 'block';
      this.display = 'block';
    } else if (content.style.display === 'block') {
      content.style.display = 'none';
      this.display = 'none';
    }
  }
}



