import { NgModule } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { SettingsComponent } from './settings/settings.component';
import { HelpComponent } from './help/help.component';
import { ProfileComponent } from './profile/profile.component';
import { MatIconModule, MatMenuModule, MatDialogModule, MatRadioModule, MatListModule, MatInputModule} from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    HeaderComponent,
    SettingsComponent,
    HelpComponent,
    ProfileComponent
  ],
  imports: [
    FontAwesomeModule,
    FormsModule,
    NgbModalModule,
    MatMenuModule,
    MatIconModule,
    MatDialogModule,
    MatRadioModule,
    ReactiveFormsModule,
    MatListModule,
    MatInputModule,
    BsDropdownModule.forRoot()
  ],
  exports: [
    HeaderComponent,
    SettingsComponent
  ],
  entryComponents: [
    SettingsComponent,
    ProfileComponent,
    HelpComponent
  ]
})
export class SharedModule { }
