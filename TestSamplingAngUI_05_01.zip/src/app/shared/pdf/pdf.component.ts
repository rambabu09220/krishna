import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-pdf',
  templateUrl: './pdf.component.html',
  styleUrls: ['./pdf.component.scss']
})
export class PdfComponent implements OnInit {
  selected: string;
  constructor(public dialogRef: MatDialogRef<PdfComponent>) { }

  ngOnInit() {
  }

  close() {
    this.dialogRef.close(this.selected);
  }

}
