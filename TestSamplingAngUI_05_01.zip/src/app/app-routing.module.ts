import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TrackingComponent } from './core/tracking/tracking.component';
import { TaskViewComponent } from './core/task-view/task-view.component';
import { TaskDetailsComponent } from './core/task-view/components/task-details/task-details.component';
import { NotesComponent } from './core/task-view/components/notes/notes.component';
import { AllocationComponent } from './core/task-view/components/allocation/allocation.component';
import { EditComponent } from './core/task-view/components/edit/edit.component';
import { PanelComponent } from './core/task-view/components/panel/panel.component';
import { SendEmailComponent } from './core/task-view/components/send-email/send-email.component';
import { CertaintyComponent } from './core/task-view/components/certainty/certainty.component';
import { AreaReportComponent } from './core/task-view/components/area-report/area-report.component';
import { OpenTasksComponent } from './core/task-view/components/open-tasks/open-tasks.component';
import { RunJObComponent } from './core/task-view/components/run-job/run-job.component';
import { ReviewComponent } from './core/task-view/components/review/review.component';

const routes: Routes = [
  {
    path: 'home',
    component: TrackingComponent
  },
  {
    path: 'taskView',
    component: TaskViewComponent,
    children: [
      {
        path: 'taskDetails',
        component: TaskDetailsComponent
      },
      {
        path: 'notes',
        component: NotesComponent
      },
      {
        path: 'allocation',
        component: AllocationComponent
      },
      {
        path: 'edit',
        component: EditComponent
      },
      {
        path: 'panel',
        component: PanelComponent
      },
      {
        path: 'sendMail',
        component: SendEmailComponent
      },
      {
        path: 'certainity',
        component: CertaintyComponent
      },
      {
        path: 'areaReport',
        component: AreaReportComponent
      },
      {
        path: 'openTasks',
        component: OpenTasksComponent
      },
      {
        path: 'runJob',
        component: RunJObComponent
      },
      {
        path: 'review',
        component: ReviewComponent
      },
      {
        path: '', redirectTo: 'taskDetails', pathMatch: 'full'
      }
    ]
  },
  {
    path: '', redirectTo: 'home', pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
